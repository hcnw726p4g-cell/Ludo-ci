extends Node2D

var rng := RandomNumberGenerator.new()
var turn := 0
var dice := 1
var winner := -1
var pieces := [0,0,0,0,0,0,0,0]
var coins := 100
var button_rect := Rect2(250, 760, 220, 80)
var colors := [Color("#D94B4B"), Color("#4B7BD9")]

func _ready():
    rng.randomize()
    queue_redraw()

func _input(event):
    if event is InputEventScreenTouch and event.pressed:
        _tap(event.position)
    elif event is InputEventMouseButton and event.pressed:
        _tap(event.position)

func _tap(p: Vector2):
    if button_rect.has_point(p) and winner == -1:
        dice = rng.randi_range(1,6)
        var idx = turn * 4
        pieces[idx] = mini(pieces[idx] + dice, 20)
        if pieces[idx] >= 20:
            winner = turn
            coins += 50
        else:
            turn = 1 - turn
        queue_redraw()
    elif winner != -1 and Rect2(240, 650, 240, 70).has_point(p):
        winner = -1
        turn = 0
        pieces = [0,0,0,0,0,0,0,0]
        queue_redraw()

func _draw():
    draw_rect(Rect2(0,0,720,900), Color("#F5E9D3"))
    draw_string(ThemeDB.fallback_font, Vector2(38,55), "LUDO AFRIQUE", HORIZONTAL_ALIGNMENT_LEFT, -1, 34, Color("#2D241E"))
    draw_string(ThemeDB.fallback_font, Vector2(40,90), "Pièces : %d" % coins, HORIZONTAL_ALIGNMENT_LEFT, -1, 24, Color("#6B4E2E"))
    draw_string(ThemeDB.fallback_font, Vector2(430,90), "Tour : Joueur %d" % (turn+1), HORIZONTAL_ALIGNMENT_LEFT, -1, 22, colors[turn])

    var board = Rect2(55,120,610,610)
    draw_rect(board, Color("#FFFDF7"), true)
    draw_rect(board, Color("#4B3B2A"), false, 5)
    var cell = 610.0/11.0
    for y in range(11):
        for x in range(11):
            var r=Rect2(55+x*cell,120+y*cell,cell,cell)
            var c=Color("#F8F0E2")
            if x==5 or y==5: c=Color("#E7D7B9")
            if x<4 and y<4: c=Color("#F3C2C2")
            if x>6 and y>6: c=Color("#BFD1F2")
            draw_rect(r,c,true)
            draw_rect(r,Color("#C5B69F"),false,1)

    # bases
    draw_rect(Rect2(75,140,190,190), Color("#E88D8D"), true)
    draw_rect(Rect2(455,520,190,190), Color("#8DA9E8"), true)
    for i in range(4):
        var a=Vector2(125+(i%2)*85,190+(i/2)*85)
        draw_circle(a,24,Color("#FFFFFF"))
        draw_circle(a,16,colors[0])
        var b=Vector2(505+(i%2)*85,570+(i/2)*85)
        draw_circle(b,24,Color("#FFFFFF"))
        draw_circle(b,16,colors[1])

    # moving pieces, simple progress track
    var p0=_track_pos(pieces[0])
    var p1=_track_pos(pieces[4])
    draw_circle(p0,22,colors[0]); draw_circle(p1,22,colors[1])
    draw_string(ThemeDB.fallback_font,p0+Vector2(-8,8),"1",HORIZONTAL_ALIGNMENT_LEFT,-1,20,Color.WHITE)
    draw_string(ThemeDB.fallback_font,p1+Vector2(-8,8),"2",HORIZONTAL_ALIGNMENT_LEFT,-1,20,Color.WHITE)

    draw_rect(button_rect, Color("#2E7D32") if winner==-1 else Color("#777777"), true)
    var txt="LANCER LE DÉ" if winner==-1 else "VICTOIRE !"
    draw_string(ThemeDB.fallback_font, Vector2(278,810), txt, HORIZONTAL_ALIGNMENT_LEFT, -1, 25, Color.WHITE)
    draw_string(ThemeDB.fallback_font, Vector2(315,735), "Dé : %d" % dice, HORIZONTAL_ALIGNMENT_LEFT, -1, 30, Color("#2D241E"))
    if winner!=-1:
        draw_string(ThemeDB.fallback_font, Vector2(215,630), "Joueur %d gagne +50 pièces !" % (winner+1), HORIZONTAL_ALIGNMENT_LEFT, -1, 24, colors[winner])
        draw_rect(Rect2(240,650,240,70),Color("#B8793D"),true)
        draw_string(ThemeDB.fallback_font,Vector2(300,695),"REJOUER",HORIZONTAL_ALIGNMENT_LEFT,-1,24,Color.WHITE)

func _track_pos(step:int)->Vector2:
    var s=mini(step,20)
    var cell=610.0/11.0
    var x=55+5*cell+cell/2
    var y=120+cell/2
    if s<=10:
        x=55+(5+s)*cell+cell/2
    else:
        x=55+(15-s)*cell+cell/2
        y=120+5*cell+cell/2
    return Vector2(x,y)
