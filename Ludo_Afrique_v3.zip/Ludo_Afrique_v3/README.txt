LUDO AFRIQUE v3

Projet Godot 4.x prêt à être importé.
Le jeu est destiné à Android. Cette version contient un plateau tactile simplifié, deux joueurs, dé, progression, victoire et pièces virtuelles.

IMPORTANT : ce ZIP est le PROJET SOURCE, pas encore un APK.
Pour fabriquer l'APK Android, il faut un environnement Godot/Android sur ordinateur ou serveur de compilation.
Aucune boutique, aucun achat de modèle ou d'assets n'est nécessaire pour ce projet.
