Ludo Afrique - version Web

Ce projet est préparé pour être exporté en jeu Web Godot et publié avec GitHub Pages.
Le workflow .github/workflows/web.yml construit automatiquement le jeu et le publie après un push sur main.

Le jeu peut ensuite être ouvert depuis Safari ou Chrome sur téléphone.
